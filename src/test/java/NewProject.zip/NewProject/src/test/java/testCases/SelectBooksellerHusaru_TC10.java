package testCases;

import com.aventstack.extentreports.Status;
import common.TestBase;
import org.testng.annotations.Test;
import pages.BlogPage;
import pages.BookSellerHusaruPage;
import pages.HomePage;

public class SelectBooksellerHusaru_TC10 extends TestBase {

    @Test()
    public void select_bookseller_husaru() throws InterruptedException {
        test = extent.createTest("add books to cart", "Case 8: User is able to add books to cart")
                .assignCategory("Functional_testcase")
                .assignAuthor("QA team");
        logger.info("Verify URL");

        openURL("https://www.cartepedia.ro/?gclid=CjwKCAjw-IWkBhBTEiwA2exyO2VKZJfeTZ0v7qKN0KFyxpqFaoDb1_XtEmAtCAcsqENCvtVm-YxmcRoCGMMQAvD_BwE");
        test.log(Status.INFO, "Open URL");
        logger.info("Open URL");

        metode.waitForElementToBeVisible(HomePage.CartepediaBanner);
        metode.scrollDown(HomePage.LibrarPersonalizatBtn);
        metode.waitForElementToBeClickable(HomePage.LibrarPersonalizatBtn);

        metode.clickOnButton(HomePage.LibrarPersonalizatBtn);
        test.log(Status.INFO, "Click on the Librar personalizat button(Homepage)");
        logger.info("Click on the Librar personalizat button(Homepage)");

        metode.waitForElementToBeVisible(BlogPage.BlogulCartepediaImage);
        metode.scrollDown(BlogPage.BooksellerSHusaru);
        test.log(Status.INFO, "Scroll down to the bookseller named Simona Husaru(Blogpage)");
        logger.info("Scroll down to the bookseller named Simona Husaru(Blogpage)");

        metode.waitForElementToBeClickable(BlogPage.BooksellerSHusaru);
        metode.clickOnButton(BlogPage.BooksellerSHusaru);
        test.log(Status.INFO, "Click on the bookseller named Simona Husaru(Blogpage)");
        logger.info("Click on the bookseller named Simona Husaru(Blogpage)");


        metode.waitForElementToBeVisible(BookSellerHusaruPage.SimonaHusaruName);
        metode.assertTheText(BookSellerHusaruPage.SimonaHusaruName, "Husaru");
        test.log(Status.INFO, "Assert the name of the bookseller Simona Husaru(BookSellerHusaruPage)");
        logger.info("Assert the name of the bookseller Simona Husaru(BookSellerHusaruPage)");
    }


}
