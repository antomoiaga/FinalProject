package pages;

import org.openqa.selenium.By;

public class HumanitasPage {

    public static By HumanitasDescriptionText = By.xpath("/html/body/div[4]/div[1]/div[2]/div[1]/div[1]/div[1]/div/div/p");
}
