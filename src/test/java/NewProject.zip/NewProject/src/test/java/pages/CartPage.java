package pages;

import org.openqa.selenium.By;

public class CartPage {
    public static By OrderedProduct = By.xpath("/html/body/div[4]/div[1]/form[2]/div[2]/div[5]/div[1]");

    public static By AddDiscount = By.xpath("/html/body/div[4]/div[1]/form[2]/div[2]/div[1]/a/img");
}
