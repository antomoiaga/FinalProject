package pages;

import org.openqa.selenium.By;

public class RoundEarthPuzzlePage {

    public static By AddToCartGlobePuzzleBtn = By.xpath("/html/body/div[4]/div[2]/div[2]/div/div[3]/div[2]/div[1]/div[2]/div/button/div/span");
}
