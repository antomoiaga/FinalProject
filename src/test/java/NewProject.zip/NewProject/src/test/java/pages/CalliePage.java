package pages;

import org.openqa.selenium.By;

public class CalliePage {

    public static By CallieText = By.xpath("/html/body/div[3]/div[1]/div[1]/div/p[1]/span");
}
