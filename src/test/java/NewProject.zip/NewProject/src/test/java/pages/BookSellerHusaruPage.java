package pages;

import org.openqa.selenium.By;

public class BookSellerHusaruPage {

    public static By SimonaHusaruName = By.xpath("/html/body/div[2]/div/div/div[1]/div/div/div[1]/div[1]/div/h3/a");
}
