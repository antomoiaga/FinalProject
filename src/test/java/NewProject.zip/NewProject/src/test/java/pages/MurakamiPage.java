package pages;

import org.openqa.selenium.By;

public class MurakamiPage {
    public static By MurakamiBookItem = By.xpath("/html/body/div[4]/div/div[4]/div[5]/div[1]/span[1]");
}
