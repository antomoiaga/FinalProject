package pages;

import org.openqa.selenium.By;

public class DiscountsPage {
    public static By ArthurDiscounts = By.xpath("/html/body/div[4]/div/div[2]/div[4]/a/picture/img");
}
