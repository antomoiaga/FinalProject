package pages;

import org.openqa.selenium.By;

public class ArthurPage {

    public static By HarryPotterBook = By.xpath("/html/body/div[4]/div/div[5]/div[2]/div[3]/a[1]/picture/img");
}
