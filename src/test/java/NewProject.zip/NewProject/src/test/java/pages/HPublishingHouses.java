package pages;

import org.openqa.selenium.By;

public class HPublishingHouses {

    public static By HumanitasBtn = By.linkText("Humanitas");
}
