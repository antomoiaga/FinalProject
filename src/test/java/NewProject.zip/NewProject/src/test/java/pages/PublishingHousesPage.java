package pages;

import org.openqa.selenium.By;

public class PublishingHousesPage {

    public static By HPublishingHousesBtn = By.xpath("/html/body/div[4]/div/div[1]/div[4]/div/a[8]");
}
