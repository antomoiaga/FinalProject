package pages;

import org.openqa.selenium.By;

public class BlogPage {
    public static By BlogulCartepediaImage = By.xpath("/html/body/div[1]/div/div/div/a/img");

    public static By CallieRecommendation = By.xpath("/html/body/div[2]/div[2]/div/div[2]/div[3]/div/div/div[2]/div/a/h3");

    public static By BooksellerSHusaru = By.linkText("Simona Husaru");


}
